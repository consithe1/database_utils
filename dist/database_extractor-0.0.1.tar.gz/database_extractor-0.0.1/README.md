# database-utils

## Description

This project intends to create a python package to convert a database into another format like XML, Excel, etc.

## Features to implement

- Read database content (SQLite3)
- Extract database content into a dict object
