PACKAGE_NAME = "database_extractor"
ERROR_LOG_FILE = f"{PACKAGE_NAME}_errors.log"

SEP_KEY_CHAR = "-"

CHAT_EQUIVALENT = {'8': {'13': 97}}